#include "vertexformat.hpp"

static bool isIntegerType(gpupro::VertexAttribute::Type _t)
{
	switch(_t)
	{
	case gpupro::VertexAttribute::Type::INT8:
	case gpupro::VertexAttribute::Type::UINT8:
	case gpupro::VertexAttribute::Type::INT16:
	case gpupro::VertexAttribute::Type::UINT16:
	case gpupro::VertexAttribute::Type::INT32:
	case gpupro::VertexAttribute::Type::UINT32:
		return true;
	default:
		return false;
	}
}

gpupro::VertexFormat::VertexFormat(const std::vector<VertexAttribute>& _attributes)
{
	// TODO: Generate the Vertex Array Object and bind it

	for(auto& attr : _attributes)
	{
		// TODO: Enable the attribute with index attr.attributIndex.

		// TODO: Setup all the attributes with glVertexAttribDivisor,
		// glVertexAttrib*Format and glVertexAttribBinding (last!).
		// Use glVertexAttribLFormat for DOUBLE, glVertexAttribIFormat for
		// all integer types (isIntegerType) and glVertexAttribFormat
		// otherwise.
		// For an unknown reason (driver bug?) this must be called AFTER glVertexAttrib*Format!
		// Otherwise it is overwritten and expects attribIndex == vboIndex.
	}
}

gpupro::VertexFormat::~VertexFormat()
{
	// TODO: Delete the Vertex Array Object.
}

gpupro::VertexFormat::VertexFormat(VertexFormat&& _rhs) :
	m_id(_rhs.m_id)
{
	_rhs.m_id = 0;
}

gpupro::VertexFormat& gpupro::VertexFormat::operator=(VertexFormat&& _rhs)
{
	// TODO: Delete the Vertex Array Object.

	m_id = _rhs.m_id;
	_rhs.m_id = 0;

	return *this;
}
