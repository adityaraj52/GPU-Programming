Roel Reijerse 2006
http://creativecommons.org/licenses/by-nc-sa/3.0/
http://reije081.home.xs4all.nl/skyboxes/